package com.example

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.speech.tts.TextToSpeech
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.CyberNeonPink
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.delay
import java.util.Locale
import kotlin.math.roundToInt
import kotlin.random.Random

data class GameSite(val id: String, val name: String, val url: String, val badge: String)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var isTtsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        tts = TextToSpeech(this, this)

        val prefs = getSharedPreferences("mehedi_bot_prefs", Context.MODE_PRIVATE)

        setContent {
            MyApplicationTheme {
                MainScreen(
                    prefs = prefs,
                    onVibrate = { duration -> triggerVibrate(duration) },
                    onSpeak = { text -> speakText(text) }
                )
            }
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.US
            isTtsReady = true
        }
    }

    private fun speakText(text: String) {
        if (isTtsReady && text.isNotBlank()) {
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "MehediBotVoice")
        }
    }

    private fun triggerVibrate(duration: Long) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator?.vibrate(
                    VibrationEffect.createOneShot(duration, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                @Suppress("DEPRECATION")
                vibrator?.vibrate(duration)
            }
        } catch (_: Exception) {}
    }

    override fun onDestroy() {
        super.onDestroy()
        tts?.stop()
        tts?.shutdown()
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun MainScreen(
    prefs: SharedPreferences,
    onVibrate: (Long) -> Unit,
    onSpeak: (String) -> Unit
) {
    val context = LocalContext.current
    val density = LocalDensity.current
    val configuration = LocalConfiguration.current

    // Screen dimension limits for dragging
    val screenWidthPx = with(density) { configuration.screenWidthDp.dp.toPx() }
    val screenHeightPx = with(density) { configuration.screenHeightDp.dp.toPx() }

    // Authentication State
    var isUnlocked by remember { mutableStateOf(prefs.getBoolean("is_unlocked", false)) }
    var enteredPassword by remember { mutableStateOf("") }
    var passwordError by remember { mutableStateOf(false) }

    // Active Game Website (DK Win & HG Nice are primary)
    val dkWinUrl = "https://dkwin15.com/#/register?invitationCode=82626111964"
    val hgNiceUrl = "https://hgnice.org/#/register?invitationCode=557551956786"

    val allGames = remember {
        listOf(
            GameSite("dkwin", "DK Win", dkWinUrl, "VIP"),
            GameSite("hgnice", "HG Nice", hgNiceUrl, "NEW"),
            GameSite("bdg", "BDG Game", "https://bdggame.com", "HOT"),
            GameSite("91club", "91 Club", "https://91club.com", "POPULAR"),
            GameSite("tiranga", "Tiranga Games", "https://tirangagames.top", "LIVE"),
            GameSite("daman", "Daman Games", "https://damangames.bet", "CLASSIC")
        )
    }

    var currentSiteUrl by remember {
        mutableStateOf(prefs.getString("saved_game_url", dkWinUrl) ?: dkWinUrl)
    }

    var gameWebViewRef by remember { mutableStateOf<WebView?>(null) }
    var hudWebViewRef by remember { mutableStateOf<WebView?>(null) }

    var showGamePicker by remember { mutableStateOf(false) }
    var showInfoDialog by remember { mutableStateOf(false) }
    var customUrlInput by remember { mutableStateOf("") }
    var isHudVisible by remember { mutableStateOf(true) }
    var isHudMinimized by remember { mutableStateOf(false) }

    // Draggable position state for HUD
    val defaultOffsetX = with(density) { (configuration.screenWidthDp - 250).dp.toPx() }.coerceAtLeast(20f)
    val defaultOffsetY = with(density) { 120.dp.toPx() }

    var offsetX by remember { mutableFloatStateOf(defaultOffsetX) }
    var offsetY by remember { mutableFloatStateOf(defaultOffsetY) }

    // Handle Android Back Navigation
    BackHandler {
        if (gameWebViewRef?.canGoBack() == true) {
            gameWebViewRef?.goBack()
        } else {
            Toast.makeText(context, "Press Home to minimize Mehedi Vai AI Bot", Toast.LENGTH_SHORT).show()
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
            .statusBarsPadding()
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // =======================================================
            // LAYER 1: THE REAL BACKGROUND GAME WEBSITE (DK Win / HG Nice)
            // =======================================================
            Column(modifier = Modifier.fillMaxSize()) {
                // Top Cyber Game Switcher Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(DarkSurface)
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                        .border(1.dp, Brush.horizontalGradient(listOf(CyberGreen, CyberCyan)), RoundedCornerShape(8.dp)),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    // Fast Switch: DK Win
                    val isDkActive = currentSiteUrl.contains("dkwin")
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isDkActive) CyberGreen else Color(0xFF16222F))
                            .clickable {
                                currentSiteUrl = dkWinUrl
                                prefs.edit().putString("saved_game_url", dkWinUrl).apply()
                                gameWebViewRef?.loadUrl(dkWinUrl)
                                onVibrate(50)
                            }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "🎲 DK WIN",
                            color = if (isDkActive) Color.Black else Color.White,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    // Fast Switch: HG Nice
                    val isHgActive = currentSiteUrl.contains("hgnice")
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isHgActive) CyberCyan else Color(0xFF16222F))
                            .clickable {
                                currentSiteUrl = hgNiceUrl
                                prefs.edit().putString("saved_game_url", hgNiceUrl).apply()
                                gameWebViewRef?.loadUrl(hgNiceUrl)
                                onVibrate(50)
                            }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "🔥 HG NICE",
                            color = if (isHgActive) Color.Black else Color.White,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    // More platforms
                    IconButton(
                        onClick = { showGamePicker = true },
                        modifier = Modifier
                            .size(32.dp)
                            .testTag("more_games_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Casino,
                            contentDescription = "Other Platforms",
                            tint = Color.White
                        )
                    }

                    // Reload current website
                    IconButton(
                        onClick = { gameWebViewRef?.reload() },
                        modifier = Modifier
                            .size(32.dp)
                            .testTag("reload_website_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Reload Site",
                            tint = CyberGreen
                        )
                    }

                    // Bot HUD Visibility Toggle
                    IconButton(
                        onClick = { isHudVisible = !isHudVisible },
                        modifier = Modifier
                            .size(32.dp)
                            .testTag("toggle_hud_button")
                    ) {
                        Icon(
                            imageVector = if (isHudVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                            contentDescription = "Toggle HUD",
                            tint = CyberNeonPink
                        )
                    }

                    // Info / Password modal
                    IconButton(
                        onClick = { showInfoDialog = true },
                        modifier = Modifier
                            .size(32.dp)
                            .testTag("info_help_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "Info & Password",
                            tint = CyberCyan
                        )
                    }
                }

                // Full-Screen Game Website AndroidView
                AndroidView(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("game_webview"),
                    factory = { ctx ->
                        WebView(ctx).apply {
                            settings.apply {
                                javaScriptEnabled = true
                                domStorageEnabled = true
                                databaseEnabled = true
                                allowFileAccess = true
                                allowContentAccess = true
                                mediaPlaybackRequiresUserGesture = false
                                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                                userAgentString = "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36"
                                useWideViewPort = true
                                loadWithOverviewMode = true
                                setSupportMultipleWindows(true)
                                javaScriptCanOpenWindowsAutomatically = true
                            }

                            webChromeClient = object : WebChromeClient() {
                                override fun onPermissionRequest(request: PermissionRequest?) {
                                    request?.grant(request.resources)
                                }
                            }

                            webViewClient = object : WebViewClient() {
                                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                                    return false
                                }
                            }

                            loadUrl(currentSiteUrl)
                            gameWebViewRef = this
                        }
                    }
                )
            }

            // =======================================================
            // LAYER 2: FLOATING MEHEDI VAI AI PREDICTION HUD (DRAGGABLE)
            // =======================================================
            if (isUnlocked && isHudVisible) {
                if (!isHudMinimized) {
                    // Full Floating HUD Box
                    Box(
                        modifier = Modifier
                            .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
                            .size(width = 240.dp, height = 350.dp)
                            .shadow(16.dp, RoundedCornerShape(20.dp))
                            .clip(RoundedCornerShape(20.dp))
                            .border(2.dp, CyberGreen, RoundedCornerShape(20.dp))
                            .pointerInput(Unit) {
                                detectDragGestures { change, dragAmount ->
                                    change.consume()
                                    val newX = offsetX + dragAmount.x
                                    val newY = offsetY + dragAmount.y
                                    offsetX = newX.coerceIn(0f, screenWidthPx - with(density) { 240.dp.toPx() })
                                    offsetY = newY.coerceIn(0f, screenHeightPx - with(density) { 360.dp.toPx() })
                                }
                            }
                            .testTag("floating_hud_box")
                    ) {
                        AndroidView(
                            modifier = Modifier.fillMaxSize(),
                            factory = { ctx ->
                                WebView(ctx).apply {
                                    setBackgroundColor(0) // Transparent
                                    setLayerType(View.LAYER_TYPE_HARDWARE, null)
                                    settings.apply {
                                        javaScriptEnabled = true
                                        domStorageEnabled = true
                                        databaseEnabled = true
                                        allowFileAccess = true
                                        allowContentAccess = true
                                        mediaPlaybackRequiresUserGesture = false
                                        mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                                    }

                                    webChromeClient = WebChromeClient()
                                    webViewClient = WebViewClient()

                                    addJavascriptInterface(
                                        WebAppInterface(
                                            onVibrate = onVibrate,
                                            onSpeak = onSpeak,
                                            onToast = { msg ->
                                                Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
                                            }
                                        ),
                                        "AndroidNative"
                                    )

                                    loadUrl("file:///android_asset/bot/hud.html")
                                    hudWebViewRef = this
                                }
                            }
                        )
                    }
                } else {
                    // Minimized Floating Cyber Pill Badge
                    Box(
                        modifier = Modifier
                            .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
                            .shadow(12.dp, RoundedCornerShape(25.dp))
                            .clip(RoundedCornerShape(25.dp))
                            .background(Color(0xE60A101A))
                            .border(2.dp, CyberGreen, RoundedCornerShape(25.dp))
                            .clickable {
                                isHudMinimized = false
                                onVibrate(40)
                            }
                            .pointerInput(Unit) {
                                detectDragGestures { change, dragAmount ->
                                    change.consume()
                                    offsetX = (offsetX + dragAmount.x).coerceIn(0f, screenWidthPx - 200f)
                                    offsetY = (offsetY + dragAmount.y).coerceIn(0f, screenHeightPx - 200f)
                                }
                            }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(CyberGreen)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "⚡ MEHEDI AI",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "EXPAND",
                                color = CyberGreen,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }
                }
            }

            // =======================================================
            // LAYER 3: HACKER MATRIX INTRO & VIP LOGIN SPLASH SCREEN
            // =======================================================
            AnimatedVisibility(
                visible = !isUnlocked,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                HackerMatrixSplashScreen(
                    enteredPassword = enteredPassword,
                    onPasswordChange = {
                        enteredPassword = it
                        passwordError = false
                    },
                    passwordError = passwordError,
                    onUnlock = {
                        if (enteredPassword.trim() == "MEHEDIVAI115") {
                            isUnlocked = true
                            prefs.edit().putBoolean("is_unlocked", true).apply()
                            onVibrate(150)
                            onSpeak("Access Granted. Initializing Mehedi Vai AI Core.")
                            Toast.makeText(context, "Access Granted! Welcome.", Toast.LENGTH_SHORT).show()
                        } else {
                            passwordError = true
                            onVibrate(300)
                            onSpeak("Access Denied. Invalid key.")
                            Toast.makeText(context, "Invalid VIP Key! Use: MEHEDIVAI115", Toast.LENGTH_SHORT).show()
                        }
                    }
                )
            }
        }
    }

    // Dialog: Game Platform Switcher
    if (showGamePicker) {
        AlertDialog(
            onDismissRequest = { showGamePicker = false },
            title = {
                Text(
                    text = "SELECT BETTING PLATFORM",
                    color = CyberGreen,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 16.sp
                )
            },
            text = {
                Column {
                    Text(
                        text = "Switch background live website instantly:",
                        color = Color.LightGray,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    LazyColumn(modifier = Modifier.height(230.dp)) {
                        items(allGames) { game ->
                            val isSelected = currentSiteUrl == game.url
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clickable {
                                        currentSiteUrl = game.url
                                        prefs.edit().putString("saved_game_url", game.url).apply()
                                        gameWebViewRef?.loadUrl(game.url)
                                        showGamePicker = false
                                        onVibrate(50)
                                    },
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isSelected) Color(0xFF003322) else DarkSurface
                                ),
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (isSelected) CyberGreen else Color(0xFF223344)
                                )
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = game.name,
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        )
                                        Text(
                                            text = game.url.substringBefore("/#").substringBefore("?"),
                                            color = Color.Gray,
                                            fontSize = 10.sp
                                        )
                                    }
                                    Box(
                                        modifier = Modifier
                                            .background(
                                                if (isSelected) CyberGreen else Color(0xFF1E293B),
                                                RoundedCornerShape(4.dp)
                                            )
                                            .padding(horizontal = 8.dp, vertical = 3.dp)
                                    ) {
                                        Text(
                                            text = game.badge,
                                            color = if (isSelected) Color.Black else CyberGreen,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = customUrlInput,
                        onValueChange = { customUrlInput = it },
                        placeholder = { Text("Enter custom website URL...", fontSize = 12.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyberGreen,
                            unfocusedBorderColor = Color.Gray,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.LightGray
                        ),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (customUrlInput.isNotBlank()) {
                            val url = if (!customUrlInput.startsWith("http")) "https://$customUrlInput" else customUrlInput
                            currentSiteUrl = url
                            prefs.edit().putString("saved_game_url", url).apply()
                            gameWebViewRef?.loadUrl(url)
                        }
                        showGamePicker = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberGreen)
                ) {
                    Text("LOAD SITE", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showGamePicker = false }) {
                    Text("CANCEL", color = Color.LightGray)
                }
            },
            containerColor = DarkBackground
        )
    }

    // Dialog: Bot Info & Password
    if (showInfoDialog) {
        AlertDialog(
            onDismissRequest = { showInfoDialog = false },
            title = {
                Text(
                    text = "MEHEDI VAI AI VIP INFO",
                    color = CyberCyan,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 16.sp
                )
            },
            text = {
                Column {
                    Text(
                        text = "VIP ACCESS KEY:",
                        color = Color.Yellow,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "MEHEDIVAI115",
                        color = CyberGreen,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 20.sp,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 2.sp,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "• Both DK Win & HG Nice live in background\n" +
                                "• 20+ Neural Signal Algorithms Active\n" +
                                "• Markov Chain & Bayesian Clustered Engine\n" +
                                "• Entropy Cycle & Volatility Squeeze Breakout\n" +
                                "• Real-Time 30s / 1m Countdown Clock Sync\n" +
                                "• Draggable, minimizable, & resizable HUD\n" +
                                "• Voice announcer & win celebration audio",
                        color = Color.LightGray,
                        fontSize = 12.sp,
                        lineHeight = 18.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = {
                            isUnlocked = false
                            prefs.edit().putBoolean("is_unlocked", false).apply()
                            showInfoDialog = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF331111)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("🔒 LOCK BOT SESSION", color = Color(0xFFFF5555), fontWeight = FontWeight.Bold)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { showInfoDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberCyan)
                ) {
                    Text("CLOSE", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = DarkBackground
        )
    }
}

// =========================================================================
// HACKER MATRIX FULL-SCREEN SPLASH UNLOCK COMPONENT
// =========================================================================
@Composable
fun HackerMatrixSplashScreen(
    enteredPassword: String,
    onPasswordChange: (String) -> Unit,
    passwordError: Boolean,
    onUnlock: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "matrix_rain")
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1000f,
        animationSpec = infiniteRepeatable(
            animation = tween(20000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rain_phase"
    )

    val terminalLines = remember { mutableStateListOf("> INITIALIZING MEHEDI VAI NEURAL CORE V5.0...") }

    LaunchedEffect(Unit) {
        delay(600)
        terminalLines.add("> LOADING 20+ HARMONIC PATTERN ENGINES...")
        delay(600)
        terminalLines.add("> CONNECTED: DK WIN & HG NICE HUBS...")
        delay(600)
        terminalLines.add("> VIP ACCESS REQUIRED: ENTER 'MEHEDIVAI115'...")
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF06090E))
    ) {
        // Digital Matrix Rain Canvas
        Canvas(modifier = Modifier.fillMaxSize()) {
            val cols = (size.width / 40).toInt().coerceAtLeast(10)
            for (i in 0 until cols) {
                val x = i * 40f + 20f
                val seed = (i * 137).toFloat()
                val y = ((phase * 2f + seed) % (size.height + 200f)) - 100f

                drawCircle(
                    color = if (i % 3 == 0) Color(0xFF00E676) else Color(0xFF00CFFF),
                    radius = 3f,
                    center = Offset(x, y),
                    alpha = 0.6f
                )
                drawCircle(
                    color = Color.White,
                    radius = 1.5f,
                    center = Offset(x, y - 20f),
                    alpha = 0.4f
                )
            }
        }

        // Center Cyber Card
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(30.dp, RoundedCornerShape(20.dp)),
                colors = CardDefaults.cardColors(containerColor = Color(0xF00D1520)),
                border = androidx.compose.foundation.BorderStroke(
                    1.5.dp,
                    if (passwordError) CyberNeonPink else CyberGreen
                ),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Glowing Cyber Badge
                    Box(
                        modifier = Modifier
                            .size(80.dp)
                            .clip(CircleShape)
                            .background(Brush.sweepGradient(listOf(CyberGreen, CyberCyan, CyberNeonPink, CyberGreen)))
                            .padding(3.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.hacker_logo),
                            contentDescription = "Hacker Logo",
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(CircleShape),
                            contentScale = ContentScale.Crop
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "MEHEDI VAI AI BOT",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.5.sp
                    )

                    Text(
                        text = "ULTRA VIP PREDICTION MATRIX V5.0",
                        color = CyberCyan,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Terminal Box
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xCC000000))
                            .border(1.dp, Color(0x3300FF88), RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        Column {
                            terminalLines.takeLast(3).forEach { line ->
                                Text(
                                    text = line,
                                    color = CyberGreen,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Password Input Field
                    OutlinedTextField(
                        value = enteredPassword,
                        onValueChange = onPasswordChange,
                        placeholder = {
                            Text(
                                text = "ENTER VIP KEY...",
                                color = Color.Gray,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = { onUnlock() }),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("vip_password_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyberGreen,
                            unfocusedBorderColor = if (passwordError) CyberNeonPink else Color(0xFF334455),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Unlock Button
                    Button(
                        onClick = onUnlock,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("unlock_bot_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = CyberGreen),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "⚡ UNLOCK AI BOT",
                            color = Color.Black,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 14.sp,
                            letterSpacing = 1.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "KEY: MEHEDIVAI115",
                        color = Color.Yellow,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

class WebAppInterface(
    private val onVibrate: (Long) -> Unit,
    private val onSpeak: (String) -> Unit,
    private val onToast: (String) -> Unit
) {
    @JavascriptInterface
    fun triggerVibrate(durationMs: Long) {
        onVibrate(durationMs)
    }

    @JavascriptInterface
    fun speakVoice(text: String) {
        onSpeak(text)
    }

    @JavascriptInterface
    fun showToast(msg: String) {
        onToast(msg)
    }
}
